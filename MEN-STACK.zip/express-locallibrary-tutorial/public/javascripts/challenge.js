var solveButton = document.getElementById("solve24")

solveButton.addEventListener("click", function() {
  document.getElementById("solution").innerHTML = solveButton.getAttribute('solution')
}) 
var notifications = document.getElementById('notifications')
var mathButton = document.getElementById('twoNum')

var gameStates = [] //store game states so we can go back
mathButton.addEventListener('click', function() {
  notifications.innerHTML = '' //reset notifications
  var elem = document.getElementById('game').innerHTML
  
  var n1 = document.querySelector("[name='num1']").value
  var operator = document.querySelector("[name='operator']").value
  var n2 = document.querySelector("[name='num2']").value
  
  gameStates.push(elem.slice(14, elem.length).split(","))

  var game = gameStates[gameStates.length-1] //get current game state
  
  var idx1 = game.indexOf(n1)
  var idx2 = -1
  //prevent idx1 == idx2
  for(var i = 0; i < game.length; i++) {
    if(idx1 != i && n2 == game[i]) {
      idx2 = i 
      break
    }
  }
  
  if(idx1 == -1 || idx2 == -1) {
    notifications.innerHTML = 'you are using numbers that do not exist'
    gameStates.pop()
    return
  }
  var newGame = []
  for(var i = 0; i < game.length; i++) {
    if(i != idx1 && i != idx2) newGame.push(game[i])
  }
  try {
    var res = eval(n1+operator+n2)
    newGame.push(res)
  } catch (e) {
    notifications.innerHTML = "invalid operator, valid operators are (+, -, /, *)"
    gameStates.pop()
  }
  if(newGame.length == 1 && newGame[0] == 24) document.getElementById('game').innerHTML = "you win! nice job!"
  else document.getElementById('game').innerHTML = `Current game: ${newGame}`
})

var undoButton = document.getElementById('undo')

undo.addEventListener('click', function() {
  document.getElementById('game').innerHTML = 'current game: '+ gameStates.pop()
})
